#ifndef PROP_H
#define PROB_H

typedef int Proposition;
#endif
