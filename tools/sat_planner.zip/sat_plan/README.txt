Verified SAT-Based AI Planning
==============================

To build the proof document for this entry and generate encoding and decoding program, please do the following steps.

  1. Download Isabelle2020 from https://isabelle.in.tum.de/ and extract it

  2. Run isabelle and close it by isabelle_path/bin/isabelle jedit. This is to initialise Isabelle's ROOTS file.

  3. Execute the following command to build the proof document "document.pdf" and generate the code for encoding and decoding (will be put into the same directory)

    isabelle_path/bin/isabelle build -cv -o threads=4 -o document=pdf -o document_output=. -d ./ Verified_SAT_Based_AI_Planning

    The proof document is document.pdf and it will be generated here. You can also browse the theory files using isabelle_path/bin/isabelle jedit *.thy

To build and run the planner, do the following steps.

  1. Download the mlton compiler for ML.

  2. Change directory to path_to_this_dir/code

  3. Run the script ./build.sh: this will build the verified code, and extract all the needed tools for running the planner. The extracted needed tools are: gratchk and gratgen for verified certificate checking by Peter Lammich, kissat-master the SAT solver by Armin Biere, and sml-parse-comb-master.zip which is the parsing library by Taran Lynn.

  4. You can use it to solve a problem by running

    ./compute_plan.sh 100 ../example/outpus.sas kissat-master/build/kissat

    The first argument is the horizon, the second is the problem to solve which should be in Fast Downward's translator formtat, and the third is a path to a SAT solver executable.
