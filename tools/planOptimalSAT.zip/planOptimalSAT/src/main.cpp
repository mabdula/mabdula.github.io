#include "../../utils/util.h"
#include <src/preprocess/helper_functions.h>
#include "stripsOptimal.h"

//#define experiments

int max_atom_dom_size = 0;
int max_atom_actions_size = 0;
int search_size = 0;
int number_state_vars = 0;
int number_actions = 0;
int DAGs = 0;
int SAS_VARs = 0;
int DAG_size = 1;
double bound_computation_time = 0;
double symmetry_compuation_time = 0;

int assign_sat_encoding(char* arg)
  {
    if(strcmp(arg, "-MADAGASCAR_ALL") == 0)
      {
        return MADAGASCAR_ALL;
      }
    else if(strcmp(arg, "-MADAGASCAR_EX") == 0)
      {
        return MADAGASCAR_EX;
      }
    else if(strcmp(arg, "-MADAGASCAR_SEQ") == 0)
      {
        return MADAGASCAR_SEQ;
      }
    return -1;
  }

int assign_kissat_mode(char* arg)
  {
    if(strcmp(arg, "-SAT") == 0)
      {
        return KISSAT_SAT;
      }
    else if(strcmp(arg, "-UNSAT") == 0)
      {
        return KISSAT_UNSAT;
      }
    else if(strcmp(arg, "-NEUTRAL") == 0)
      {
        return KISSAT_NA;
      }
    return -1;
  }

bool assign_sym_mode(char* arg)
  {
    if(strcmp(arg, "-SYM") == 0)
      {
        return true;
      }
    else if(strcmp(arg, "-NO_SYM") == 0)
      {
        return false;
      }
  }

int assign_sol_method(char* arg)
  {
    if(strcmp(arg, "-SMT") == 0)
      {
        return SMT;
      }
    else if(strcmp(arg, "-SAT") == 0)
      {
        return KISSAT;
      }
    else if(strcmp(arg, "-MADAGASCAR") == 0)
      {
        return MADAGASCAR;
      }
  }



int main(int argc, char** argv)
  {
    bool metric;
    vector<Variable> internal_variables;
    vector<Variable *> variables;
    vector<MutexGroup> mutexes;
    State initial_state;
    vector<std::pair<Variable *, int> > goals;
    vector<Operator> operators;
    vector<Axiom> axioms;
    clock_t start, end;
    start = clock();
    read_preprocessed_problem_description(cin,
                                          metric,
 					  internal_variables,
    					  variables,
					  mutexes,
					  initial_state,
					  goals,
					  operators,
					  axioms);
    char*name = (char*)"Prob";


    // std::vector<DomainTransitionGraph> transition_graphs;
    // CausalGraph cg(variables, operators, axioms, goals);
    // const std::vector<Variable *> &ordering = cg.get_variable_ordering();
    // build_DTGs(ordering, operators, axioms, transition_graphs);
    // printf("Computed %d transition graphs\r\n", (int)transition_graphs.size());


    StripsProblem prob(variables, initial_state, goals, operators, mutexes, name, axioms);
    // printf("num goals = %d\r\n", (int)goals.size());
    // prob.writePorblemPDDL();
    int ubound_length = strtol(argv[1],NULL,10);
    int ubound_cost = strtol(argv[2],NULL,10);
    int lbound_cost = strtol(argv[3],NULL,10);
    StripsOptimal optimal;
    optimal.problem = prob;
    optimal.sol_method = assign_sol_method(argv[4]);
    if (optimal.sol_method == SMT)
      {
        printf("Optimal plan found with cost: %lld\n", optimal.computeOptimalPlanCostSMT(ubound_length, ubound_cost, lbound_cost));
      }
    else
      {
        optimal.sat_encoding = assign_sat_encoding(argv[5]);
        optimal.sym_break = assign_sym_mode(argv[6]);
        optimal.kissat_mode = assign_kissat_mode(argv[7]);

    //printf("%lld\n", prob.computeOptimalPlanCostSMT(ubound_length, ubound_cost, lbound_cost));
        long long int cost = optimal.computeOptimalPlanCostSAT(ubound_length, ubound_cost, lbound_cost);
        cout <<"Optimal plan found with cost: " << cost << endl;
      }
  }

