#include "stripsOptimal.h"
#include <stdlib.h>
#include <string.h>

void StripsOptimal::writePorblemPDDLwithCosts(long long int ubound_c)
{  
  char* domName = (char*)malloc(strlen(problem.name) + strlen("dom.pddl")+ 1);
  domName = strcpy(domName, "dom");
  domName = strcat(domName, problem.name);
  domName = strcat(domName, ".pddl");
  FILE* domain = fopen(domName, "w");
  free(domName);
  fprintf(domain, "(define (domain quotient)\r\n");
  fprintf(domain, "(:predicates ");
  for(int i = 0 ; i < (int)problem.domSize ; i ++)
    {
      fprintf(domain, "(v%d) ", i);
    }
  fprintf(domain, "(used ?c - object) ");
  fprintf(domain, ")\r\n");
  fprintf(domain, "(:constants ");
  for(int i = 0 ; i < (int)ubound_c ; i ++)
    {
      fprintf(domain, "c%d ", i);
    }
  fprintf(domain, " - object)\r\n");
  for(size_t i = 0 ; i < problem.actions.size() ; i ++)
    {
      fprintf(domain, "(:action a%d\r\n", (int) i);

      fprintf(domain, ":parameters (");
      for(size_t j = 0 ; j < problem.actions[i].cost ; j ++)
        {
          fprintf(domain, "?c%d ", j);
        }  
      fprintf(domain, " - object)\r\n");

      fprintf(domain, ":precondition (and ");
      for(size_t j = 0 ; j < problem.actions[i].preconditions.Trues.size() ; j ++)
        {
          fprintf(domain, "(v%d) ", problem.actions[i].preconditions.Trues[j]);
        }  
      for(size_t j = 0 ; j < problem.actions[i].preconditions.Falses.size() ; j ++)
        {
          fprintf(domain, "(not (v%d)) ", problem.actions[i].preconditions.Falses[j]);
        }  
      for(size_t j = 0 ; j < problem.actions[i].cost ; j ++)
        {
          fprintf(domain, "(not (used ?c%d)) ", j);
        }  
      for(size_t j = 0 ; j < problem.actions[i].cost ; j ++)
        {
          for(size_t k = j + 1 ; k < problem.actions[i].cost ; k ++)
            {
              fprintf(domain, "(not (= ?c%d ?c%d)) ", j, k);
            }
        }  
      fprintf(domain, ")\r\n");
      fprintf(domain, ":effect (and ");
      for(size_t j = 0 ; j < problem.actions[i].effects.Trues.size() ; j ++)
        {
          fprintf(domain, "(v%d) ", problem.actions[i].effects.Trues[j]);
        }  
      for(size_t j = 0 ; j < problem.actions[i].cost ; j ++)
        {
          fprintf(domain, "(used ?c%d) ", j);
        }  
      for(size_t j = 0 ; j < problem.actions[i].effects.Falses.size() ; j ++)
        {
          fprintf(domain, "(not (v%d)) ", problem.actions[i].effects.Falses[j]);
        }  
      fprintf(domain, "(increase (total-cost) %d) ", problem.actions[i].cost);
      fprintf(domain, ")\r\n");
      fprintf(domain, ")\r\n");
    }
  fprintf(domain, "\r\n)");
  fclose(domain);
  char* factName = (char*)malloc(strlen(problem.name) + strlen("fact.pddl")+ 1);
  factName = strcpy(factName, "fact");
  factName = strcat(factName, problem.name);
  factName = strcat(factName, ".pddl");
  FILE* facts = fopen(factName, "w");
  free(factName);
  fprintf(facts, "(define (problem quotientProb)\r\n");
  fprintf(facts, "(:domain quotient)\r\n");
  fprintf(facts, "(:init ");
  std::set<Proposition >::iterator init_iter = problem.initial_state_vars.begin();
  for(size_t i = 0 ; i < problem.initial_state_vars.size() ; i ++)
    {
      fprintf(facts, "(v%d) ", *init_iter);
      init_iter++;
    }  
  fprintf(facts, ")\r\n");
  fprintf(facts, "(:goal (and ");
  std::set<Proposition >::iterator goal_iter = problem.goals.begin();
  for(size_t i = 0 ; i < problem.goals.size() ; i ++)
    {
      fprintf(facts, "(v%d) ", *goal_iter);
      goal_iter++;
    }
  // std::set<int >::iterator common_iter = commResources.begin();
  // for(size_t i = 0 ; i < commResources.size() ; i ++)
  //   {
  //     Proposition tempProp;
  //     tempProp = *common_iter;
  //     if(initial_state_vars.find(tempProp) != initial_state_vars.end())
  //       fprintf(facts, "(v%d) ", *common_iter);
  //     //This is removed because there are no negative literals required as preconds
  //     /* else  */
  //     /*   fprintf(facts, "(not (v%d)) ", *common_iter); */
  //     common_iter++;
  //   }
  fprintf(facts, ")))");
  fclose(facts);
}

void mutex_vars(std::vector<Proposition> vars, unsigned int t, FILE* file)
  {
    fprintf(file, "\n;;Mutex constraints\n");
    std::vector<int>::iterator var_iter2 = vars.begin();
    for(size_t i = 0; i < vars.size(); i++)
      {
	std::vector<int>::iterator var_iter3 = var_iter2 + 1;
	for(size_t j = i + 1; j < vars.size(); j++)
	  {
	    fprintf(file, "(assert (or (not v%d_%d) (not v%d_%d)))\n", (int)*var_iter2, (int)t, (int)*var_iter3, (int)t);
	    var_iter3++;
	  }
	var_iter2++;
      }
  }

void eq_states(std::set<Proposition> vars, unsigned int t1, unsigned int t2, FILE* file)
  {
    fprintf(file, "\n;;States equal\n");
    std::set<Proposition>::iterator var_iter = vars.begin();
    fprintf(file, "(and true\n");
    for(size_t j = 0; j < vars.size(); j++)
      {
        fprintf(file, " (= v%d_%d v%d_%d)", *var_iter, (int)t1, *var_iter, (int)t2);
        var_iter++;
      }
    fprintf(file, ")\n");
  }

void state(PropState state, unsigned int t, FILE* file)
  {
    fprintf(file, "\n;;State value\n");
    // printf("\n;;State value\n");

    std::vector<Proposition>::iterator var_iter = state.Trues.begin();

    fprintf(file, "(assert (and true\n");
    // printf("(assert (and true\n");
    for(size_t j = 0; j < state.Trues.size(); j++)
      {
        fprintf(file, " v%d_%d", *var_iter, (int)t);
        // printf(" v%d_%d", *var_iter, (int)t);
        var_iter++;
      }
    var_iter = state.Falses.begin();
    for(size_t j = 0; j < state.Falses.size(); j++)
      {
        fprintf(file, " (not v%d_%d)", *var_iter, (int)t);
        // printf(" (not v%d_%d)", *var_iter, (int)t);
        var_iter++;
      }
    fprintf(file, "))\n");
    // printf("))\n");
  }

void frame_axiom(std::set<Proposition> vars, unsigned int t, FILE* file)
  {
    fprintf(file, "\n;;Frame axioms\n");
    eq_states(vars, t, t + 1, file);
    fprintf(file, "\n");
  }

void props_hold(std::set<Proposition> vars, unsigned int t, FILE* file)
  {
    fprintf(file, "\n;;Those props hold:\n");
    std::set<Proposition>::iterator var_iter = vars.begin();
    fprintf(file, "(and true true");
    for(size_t j = 0; j < vars.size(); j++)
      {
        fprintf(file, " v%d_%d", *var_iter, (int)t);
        var_iter++;
      }
    fprintf(file, ")\n");
  }

void props_hold_not(std::set<Proposition> vars, unsigned int t, FILE* file)
  {
    fprintf(file, "\n;;Those props do not hold:\n");
    std::set<Proposition>::iterator var_iter = vars.begin();
    fprintf(file, "(and true true");
    for(size_t j = 0; j < vars.size(); j++)
      {
        fprintf(file, " (not v%d_%d)", *var_iter, (int)t);
        var_iter++;
      }
    fprintf(file, ")\n");
  }

void StripsOptimal::transition_smt_constraints(int i, unsigned int t, FILE* file)
  {
    std::set<Proposition> effects = vectorToSet(customUnion(problem.actions[i].effects.Falses, problem.actions[i].effects.Trues));
    std::set<Proposition> untouched_vars = setMinus(problem.dom(), effects);
    fprintf(file, "(and");
    fprintf(file, "\n;;Untouched vars stay the same\n");
    frame_axiom(untouched_vars, t, file);
    fprintf(file, ";;Preconditions");
    props_hold(vectorToSet(problem.actions[i].preconditions.Trues), t, file);
    fprintf(file, "(and ");
    fprintf(file, ";;Effects");
    props_hold(vectorToSet(problem.actions[i].effects.Trues), t+1, file);
    props_hold_not(vectorToSet(problem.actions[i].effects.Falses), t+1, file);
    fprintf(file, ")");
    fprintf(file, ")");
  }

void StripsOptimal::explicit_transition_smt_constraints(int i, unsigned int t, FILE* file)
  {
    fprintf(file, "(declare-const a%d_%d Bool)\n", i, (int)t);
    fprintf(file, "(assert (=> a%d_%d", i, (int)t);
    transition_smt_constraints(i, t, file);
    fprintf(file, "))\n");
  }


#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>

bool StripsOptimal::encodeProblemSMT(long long int h, long long int c)
  {
    mkfifo("SMTplanfile.smt2", 0666);
    pid_t pid = fork();
    if(pid == 0)
      {
        //system("cat < SMTplanfile.smt2");
        system("yices-smt2 --interactive < SMTplanfile.smt2 1> smt_plan_out 2>smt_plan_err");
        //system("./mathsat < SMTplanfile.smt2 1> smt_plan_out 2>smt_plan_err");
        //system("./run-script-smtcomp-current SMTplanfile.smt2 1> smt_plan_out 2>smt_plan_err");
        //system("~/Downloads/smtinterpol-2.5-663-gf15aa217.jar -no-success -w < SMTplanfile.smt2 1> smt_plan_out 2>smt_plan_err; exit");
        exit(0);
      }      
    int fifo_fd = open("SMTplanfile.smt2", O_WRONLY);
    if (fifo_fd == -1)
      {
        printf("Could not open FIFO 1, exiting!!!\n");
        exit(-1);
      }
    FILE *SMTplanfile;
    if((SMTplanfile = fdopen(fifo_fd, "w")) == NULL)
    {
      printf("Could not open FIFO 2, exiting!!!\n");
      exit(-1);
    }
    fprintf(SMTplanfile, "(set-logic QF_LIA)\n");    

    for(size_t t = 0; t <= h; t++)
      {
	for(size_t i = 0; i < problem.variables.size(); i++)
	  {
	    fprintf(SMTplanfile, "(declare-const v%d_%d Bool)\n", (int)i, (int)t);
	  }

	std::map<Proposition, std::vector<int> >::iterator sasiter = problem.sasVarMap.begin();
	for(size_t i = 0; i < problem.sasVarMap.size(); i++)
	  {
            if(sasiter->second.size() != 0)
              {
                std::vector<int>::iterator assiter = sasiter->second.begin();
                fprintf(SMTplanfile, "(assert (or");
                for(size_t i = 0; i < sasiter->second.size(); i++)
                  {
                    fprintf(SMTplanfile, " v%d_%d", *assiter, (int)t);
                    assiter++;
                  }
                fprintf(SMTplanfile, "))\n");
                mutex_vars(sasiter->second, t, SMTplanfile);
              }
#ifdef debug
            else
              {
                printf("SAS var %d is not in this abstraction\n", sasiter->first);
              }
#endif
            sasiter++;
          }
	for(size_t i = 0; i < problem.mutexes.size(); i++)
	  {
	    mutex_vars(problem.mutexes[i], t, SMTplanfile);
	  }
      }

    fprintf(SMTplanfile, ";;Initial State\n\n");
    state(PropState(problem.dom(), problem.initial_state_vars), 0, SMTplanfile);

    fprintf(SMTplanfile, ";;Goal\n\n");
    state(PropState(problem.goals, problem.goals), h, SMTplanfile);



    fprintf(SMTplanfile, ";;Action propositions\n\n");
    for(size_t t = 0; t < h; t++)
      {
        std::vector<GroundActionType>::iterator actiter = problem.actions.begin();
        std::vector<Proposition> action_smt_vars;
        std::vector<GroundActionType> added_actions; 


        // This is to avoid encoding more than one action in the smt encoding. This is because projection can lead to multiple
        // copies of the same action
        for(size_t i = 0; i < problem.actions.size(); i++)
          {
            // if (vectorFind(*actiter, added_actions) == -1)
            //   {
                int action_var_id = (int) i;
                action_smt_vars.push_back(action_var_id);
                // fprintf(SMTplanfile, "(declare-const a%d_%d Bool)\n", (int) action_var_id, (int)t);
                // fprintf(SMTplanfile, "(assert (=> a%d_%d", (int) action_var_id, (int)t);
                // std::set<Proposition> effects = vectorToSet(customUnion(actiter->effects.Falses, actiter->effects.Trues));
                // std::set<Proposition> untouched_vars = setMinus(dom(), effects);
                // fprintf(SMTplanfile, "(and");
                // fprintf(SMTplanfile, "\n;;Untouched vars stay the same\n");
                // frame_axiom(untouched_vars, t, SMTplanfile);
                // fprintf(SMTplanfile, ";;Preconditions");
                // props_hold(vectorToSet(actiter->preconditions.Trues), t, SMTplanfile);
                // fprintf(SMTplanfile, "(and ");
                // fprintf(SMTplanfile, ";;Effects");
                // props_hold(vectorToSet(actiter->effects.Trues), t+1, SMTplanfile);
                // props_hold_not(vectorToSet(actiter->effects.Falses), t+1, SMTplanfile);
                // fprintf(SMTplanfile, ")");
                // fprintf(SMTplanfile, ")");
                // fprintf(SMTplanfile, "))\n");
                explicit_transition_smt_constraints(i, t, SMTplanfile);
                fprintf(SMTplanfile, "(declare-const cost_%d_%d Int)\n", (int) action_var_id, (int)t);
                fprintf(SMTplanfile, "(assert (= cost_%d_%d (ite a%d_%d %d 0)))\n", (int) action_var_id, (int)t, (int) action_var_id, (int)t, actiter->cost);

                added_actions.push_back(*actiter);
                // printf ("Adding\n");
                // actiter->print();
              // }
            // else
            //   {
            //     ;
            //     // printf ("Already Added\n");
            //     // actiter->print();
            //   }
            actiter++;
          }
        // mutex_vars(action_smt_vars, t, SMTplanfile);
        fprintf(SMTplanfile, "(declare-const T%d_%d Bool)\n", (int)t, (int)(t + 1));
        fprintf(SMTplanfile, "(assert (= T%d_%d (or", (int)t, (int)(t + 1));
        for(size_t i = 0; i < action_smt_vars.size(); i++)
         {
           fprintf(SMTplanfile, " a%d_%d", action_smt_vars[i] , (int)t);
         }
        fprintf(SMTplanfile, ")))\n");
        fprintf(SMTplanfile, "(declare-const cost_%d Int)\n", (int)t);
        fprintf(SMTplanfile, "(assert (= cost_%d (+ 0 ", (int)t);
        for(size_t i = 0; i < action_smt_vars.size(); i++)
          {
            fprintf(SMTplanfile, " cost_%d_%d ", action_smt_vars[i], (int)t);
          }
        fprintf(SMTplanfile, ")))\n");

      }
    fprintf(SMTplanfile, "(declare-const cost Int)\n");
    fprintf(SMTplanfile, "(assert (= cost (+ 0 ");
    for(size_t t = 0; t < h; t++)
      {
        fprintf(SMTplanfile, " cost_%d ", (int)t);
      }
    fprintf(SMTplanfile, ")))\n");

    fprintf(SMTplanfile, "(assert (<= cost %d))\n", c);

    fprintf(SMTplanfile, ";;Every step has a transition\n\n");

    fprintf(SMTplanfile, "(assert (and");
    for(size_t t = 0; t < h; t++)
      {
        fprintf(SMTplanfile, " T%d_%d", (int)t, (int)t+1);
      }
    fprintf(SMTplanfile, "))\n");

    fprintf(SMTplanfile, "(check-sat)\n");
    //fprintf(SMTplanfile, "(check-sat)\n(get-model)\n");

    fclose(SMTplanfile);
    int status = -1;
    pid = wait(&status);
    system("rm SMTplanfile.smt2");
    FILE*SMTplanOut = fopen("smt_plan_out","r");
    char token[100];
    while(fscanf(SMTplanOut, "%s", token) != EOF)
      {
        if(strstr(token, "unsat") != NULL)
          {
#ifdef debug
            cout << "Cost gt" << c << endl;
#endif
            fclose(SMTplanOut);
            return false;
          }
        if(strstr(token, "sat") != NULL)
          {
#ifdef debug
            cout << "Cost le" << c << endl;
#endif
            fclose(SMTplanOut);
            return true;
          }
      }
    printf("Error: Plan computation failed, exiting!!!\nErrorYices output is:\r\n");
    system("cat smt_plan_out");
    system("cat smt_plan_err");
  }

long long int StripsOptimal::computeOptimalPlanCostSMT(long long int h, long long int ubound_c, long long int lbound_c)
  {
    GroundActionType NOOP;
    NOOP.cost = 0;
    problem.actions.push_back(NOOP);
    long long int c = ubound_c;
    for(c = ubound_c; c >= 0 ; c--)
      {
//#ifdef debug
//#endif
        // if (d == 11)
        //   break;
        if (!encodeProblemSMT(h, c))
          {
            //There is not a plan whose cost is d+1
            break;
          }
        printf("Current cost: %lld\n", c);
        if (c == lbound_c)
          {
            c = c - 1;
            break;
          }
      }
    return  c + 1;
  }

std::map<int,int> decToBinary(int n, int size)
  {
    std::map<int,int> binaryNum;
    int i = 0; 
    for (i = 0; i <= size; i++)
      {
        binaryNum[i] = 0;
      }
    i = 0;
    while (n > 0)
      { 
        binaryNum[i] = n % 2; 
        n = n / 2; 
        i++; 
      }    
    return binaryNum;
  }

PropState binaryToProps(std::map<int,int> binaryNum, int min_idx) 
  {
    PropState s;
    int i = 0; 
    for(i = 0; i < binaryNum.size() ; i++)
      {
        if (binaryNum[i] == 1)
          {
            s.Trues.push_back(min_idx + i);
          }
        else if (binaryNum[i] == 0)
          {
            s.Falses.push_back(min_idx + i);
          }
        else
          {
            printf("Error with binary to prop conv, exiting!\n");
            exit(-1);
          }
      }
    return s;
  }

std::vector<GroundActionType> StripsOptimal::compileActionCosts(GroundActionType act, long long int ubound_c)
  { 
    long long int c = 0;
    GroundActionType act_temp;
    int min_idx = problem.domSize;
    std::vector<GroundActionType> cost_actions;
    if (cost_actions_map.find(act.cost) == cost_actions_map.end())
      {
        for(c = 0; c <= ubound_c ; c++)
          {
            if (c + act.cost <= ubound_c)
              {
                int bit_width = (int) ceil(log2 (ubound_c));
                std::map<int,int> pre_binary = decToBinary(c, bit_width);
                std::map<int,int> eff_binary = decToBinary(c + act.cost, bit_width);
                act_temp.preconditions = binaryToProps(pre_binary, min_idx);
                act_temp.effects = binaryToProps(eff_binary, min_idx);
                act_temp.cost = act.cost;            
                cost_actions.push_back(act_temp);
                // act_temp = act;
                // int bit_width = (int) ceil(log2 (ubound_c));
                // std::map<int,int> pre_binary = decToBinary(c, bit_width);
                // std::map<int,int> eff_binary = decToBinary(c + act.cost, bit_width);
                // act_temp.preconditions = act_temp.preconditions.union2(binaryToProps(pre_binary, min_idx));
                // act_temp.effects = act_temp.effects.union2(binaryToProps(eff_binary, min_idx));
                // act_temp.cost = act.cost;
                // action_compiled.push_back(act_temp);
              }
          }
        cost_actions = factorActionSet(cost_actions);
        cost_actions_map[act.cost] = cost_actions;
      }
    else 
      {
        cost_actions = cost_actions_map[act.cost];
      }
    std::vector<GroundActionType> action_compiled;
    for(size_t i = 0 ; i < cost_actions.size() ; i ++)
      {
        action_compiled.push_back(act.union2(cost_actions[i]));
      }
    return action_compiled;
  }
 

StripsProblem StripsOptimal::compileProblemCosts(long long int ubound_c)
  {
    StripsProblem tempProb(this->problem);
#ifdef debug
    cout << "Initial actions = " << problem.actions.size() << "\n";
#endif
    tempProb.actions.clear();
    cost_actions_map.clear();
    for(size_t i = 0; i < problem.actions.size(); i++)
      {
        tempProb.actions = vectorUnion(tempProb.actions, compileActionCosts(problem.actions[i], ubound_c));
#ifdef debug
        cout << "Actions now = " << tempProb.actions.size() << "\n";
#endif
      }
    tempProb.domSize = problem.domSize + (int) ceil (log2 (ubound_c)) + 1;
    return tempProb;
  }

int StripsOptimal::encodeProblemMadagscar(long long int h, StripsProblem & prob)
  {
    srand((unsigned)(prob.domSize * prob.actions.size() + sat_encoding + kissat_mode + (int) sym_break + (int) clock()));
    long long int random = rand();

    char*dom_name = (char*)malloc(strlen("domProb.pddl") + 1000 + 1 ); 
    char*inst_name = (char*)malloc(strlen("factProb.pddl") + 1000 + 1 ); 
    sprintf(dom_name,"domProb_%d.pddl", random);
    sprintf(inst_name,"factProb_%d.pddl", random);
    FILE* dom_file = fopen(dom_name, "w");
    FILE* inst_file = fopen(inst_name, "w");
    prob.writePorblemPDDL(dom_file, inst_file);
    fclose(dom_file);
    fclose(inst_file);

    char*command = (char*)malloc(strlen("${M_DIR}/M -P 0 domProb.pddl factProb.pddl -F -T -O -b prob.cnf") + 2000 + 1 ); 
    //sprintf(command, "${M_DIR}/M domProb_%d.pddl factProb_%d.pddl -F %d -T %d -O", random, random, h, h);
    sprintf(command, "${M_DIR}/M -P %d domProb_%d.pddl factProb_%d.pddl -F %d -T %d 1> plan_out_%d 2> plan_err_%d", this->sat_encoding, random, random, h, h, random, random);
    system(command);
    //sprintf(command, "${M_DIR}/M -P %d domProb_%d.pddl factProb_%d.pddl -F %d -T %d -O -b %s & ${KISSAT_DIR}/build/kissat --unsat %s 1> plan_out_%d 2> plan_err_%d", this->sat_encoding, random, random, h, h, fifo_name, fifo_name, random, random);
    //system(command);
    sprintf(command, "rm %s %s", dom_name, inst_name);
    system(command);
    free(dom_name);
    free(inst_name);

    char*plan_out_name = (char*)malloc(strlen("plan_out") + 1000 + 1 ); 
    sprintf(plan_out_name,"plan_err_%d", random);
    sprintf(command, "cat %s > /dev/stderr", plan_out_name);    
    sprintf(plan_out_name,"plan_out_%d", random);
    sprintf(command, "cat %s", plan_out_name);    
    FILE*planOut = fopen(plan_out_name,"r");
    if(planOut == NULL)
      {
        printf("plan_out not created, exiting!!!\n");
        exit(-1);
      }
    free(command);
    free(plan_out_name);
    char token[100];
    int plan_found = -1;
    while(fscanf(planOut, "%s", token) != EOF)
      {
        if(strstr(token, "UNSAT") != NULL)
          {
#ifdef debug
            cout << "Cost gt " << c << endl;
#endif
            plan_found = 0;
          }
        else if(strstr(token, "SAT") != NULL)
          {
#ifdef debug
            cout << "Cost le " << c << endl;
#endif

            plan_found = 1;
          }
      }
    fclose(planOut);
    if(plan_found == -1)
      {
        printf("Error: Plan computation failed, exiting!!!\n");
        exit(-1);
      }
    return plan_found;
  }

int StripsOptimal::encodeProblemSAT(long long int h, StripsProblem & prob)
  {
    srand((unsigned)(prob.domSize * prob.actions.size() + sat_encoding + kissat_mode + (int) sym_break + (int) clock()));
    long long int random = rand();

    char*dom_name = (char*)malloc(strlen("domProb.pddl") + 1000 + 1 ); 
    char*inst_name = (char*)malloc(strlen("factProb.pddl") + 1000 + 1 ); 
    sprintf(dom_name,"domProb_%d.pddl", random);
    sprintf(inst_name,"factProb_%d.pddl", random);
    FILE* dom_file = fopen(dom_name, "w");
    FILE* inst_file = fopen(inst_name, "w");
    prob.writePorblemPDDL(dom_file, inst_file);
    fclose(dom_file);
    fclose(inst_file);

    char*fifo_name = (char*)malloc(strlen("prob.cnf") + 1000 + 1 ); 
    sprintf(fifo_name,"/tmp/prob_%d.cnf", random);
    mkfifo(fifo_name, 0666);
    char*fifo_name_2 = (char*)malloc(strlen("prob.cnf") + 1000 + 1 ); 
    sprintf(fifo_name_2,"/tmp/prob_%d_with_symm.cnf", random);
    mkfifo(fifo_name_2, 0666);

    char*command = (char*)malloc(strlen("${M_DIR}/M -P 0 domProb.pddl factProb.pddl -F -T -O -b prob.cnf") + 2000 + 1 ); 
    //sprintf(command, "${M_DIR}/M domProb_%d.pddl factProb_%d.pddl -F %d -T %d -O", random, random, h, h);
    if (this->sym_break)
      {
        sprintf(command, "${M_DIR}/M -P %d domProb_%d.pddl factProb_%d.pddl -F %d -T %d -O -b /dev/stdout | ./BreakID-2.5 | grep -v \"*** Reading instance from input stream.\" > %s &", this->sat_encoding, random, random, h, h, fifo_name);
      }
    else
      {
        sprintf(command, "${M_DIR}/M -P %d domProb_%d.pddl factProb_%d.pddl -F %d -T %d -O -b %s &", this->sat_encoding, random, random, h, h, fifo_name);
      }
    system(command);
    // sprintf(command, "./BreakID-2.5 -f %s > %s &", fifo_name, fifo_name_2);
    // system(command);
    const char *kissat_modes[3] = {"--sat", "--unsat", ""};
    sprintf(command, "${KISSAT_DIR}/build/kissat %s %s 1> plan_out_%d 2> plan_err_%d", kissat_modes[this->kissat_mode], fifo_name, random, random);
    //sprintf(command, "cat %s 1> plan_out_%d 2> plan_err_%d", fifo_name, random, random);
    system(command);
    
    //sprintf(command, "${M_DIR}/M -P %d domProb_%d.pddl factProb_%d.pddl -F %d -T %d -O -b %s & ${KISSAT_DIR}/build/kissat --unsat %s 1> plan_out_%d 2> plan_err_%d", this->sat_encoding, random, random, h, h, fifo_name, fifo_name, random, random);
    //system(command);
    sprintf(command, "rm %s", fifo_name);
    system(command);
    free(fifo_name);
    sprintf(command, "rm %s", fifo_name_2);
    free(fifo_name_2);
    system(command);
    sprintf(command, "rm %s %s", dom_name, inst_name);
    system(command);
    free(dom_name);
    free(inst_name);

    char*plan_out_name = (char*)malloc(strlen("plan_out") + 1000 + 1 ); 
    sprintf(plan_out_name,"plan_err_%d", random);
    sprintf(command, "cat %s > /dev/stderr", plan_out_name);    
    system(command);
    sprintf(command, "rm %s", plan_out_name);    
    system(command);
    sprintf(plan_out_name,"plan_out_%d", random);
    sprintf(command, "cat %s", plan_out_name);    
    system(command);
    FILE*planOut = fopen(plan_out_name,"r");
    if(planOut == NULL)
      {
        printf("plan_out not created, exiting!!!\n");
        exit(-1);
      }
    // sprintf(command, "grep process-time: %s | sed 's/process-/kissat/g'", plan_out_name);
    // system(command);
    char token[100];
    int plan_found = -1;
    while(fscanf(planOut, "%s", token) != EOF)
      {
        if(strstr(token, "UNSATISFIABLE") != NULL)
          {
#ifdef debug
            cout << "Cost gt " << c << endl;
#endif
            plan_found = 0;
          }
        else if(strstr(token, "SATISFIABLE") != NULL)
          {
#ifdef debug
            cout << "Cost le " << c << endl;
#endif
            plan_found = 1;
          }
      }
    fclose(planOut);
    sprintf(command, "rm %s", plan_out_name);    
    system(command);
    free(command);
    free(plan_out_name);
    if(plan_found == -1)
      {
        printf("Error: Plan computation failed, exiting!!!\n");
        exit(-1);
      }
    return plan_found;
  }

int StripsOptimal::encodeProblemSAT(long long int h, long long int c)
  {
    StripsProblem tempProb = this->compileProblemCosts(c);
    if (sol_method == KISSAT)
      return encodeProblemSAT(h, tempProb);
    else if (sol_method == MADAGASCAR)
      return encodeProblemMadagscar(h, tempProb);
  }

bool StripsOptimal::encodeProblemSAT2(long long int h, long long int c)
  {
    this->writePorblemPDDLwithCosts(c);;
    mkfifo("prob.cnf", 0666);

    char*command = (char*)malloc(strlen("${M_DIR}/M -P 0 domProb.pddl factProb.pddl -F -T -O -b prob.cnf") + 1000 + 1 ); 
    sprintf(command, "${M_DIR}/M -P 0 domProb.pddl factProb.pddl -F %d -T %d -O -b prob.cnf & ${KISSAT_DIR}/build/kissat prob.cnf 1> plan_out 2> plan_err", h, h);

    system(command);

    system("rm prob.cnf");
    FILE*planOut = fopen("plan_out","r");
    char token[100];
    while(fscanf(planOut, "%s", token) != EOF)
      {
        if(strstr(token, "UNSATISFIABLE") != NULL)
          {
#ifdef debug
            cout << "Cost gt " << c << endl;
#endif
            fclose(planOut);
            return false;
          }
        if(strstr(token, "SATISFIABLE") != NULL)
          {
#ifdef debug
            cout << "Cost le " << c << endl;
#endif
            fclose(planOut);
            return true;
          }
      }
    printf("Error: Plan computation failed, exiting!!!\nError Kissat output is:\r\n");
    system("cat plan_out");
    system("cat plan_err");
    fflush(stdout);
  }

int gcd(int a, int b) 
  { 
    if (a == 0) 
        return b; 
    return gcd(b % a, a); 
  } 
  

long long int StripsOptimal::computeOptimalPlanCostSAT(long long int h, long long int ubound_c, long long int lbound_c)
  {

    int cost_factor = problem.actions[0].cost; 
    for (int i = 1; i < problem.actions.size(); i++) 
      {
        cost_factor = gcd(problem.actions[i].cost, cost_factor);
      }
    cout << "Cost factor: " << cost_factor << "\n"; 
    fflush(stdout);
   
    for (int i = 1; i < problem.actions.size(); i++) 
      {
        problem.actions[i].cost = problem.actions[i].cost/cost_factor;
      }
    // cost_factor = 15;
    // for (int i = 1; i < problem.actions.size(); i++) 
    //   {
    //     problem.actions[i].cost = (int) ceil (((double) problem.actions[i].cost)/(double)cost_factor);
    //   }
    ubound_c = (int) floor ((long) ubound_c/cost_factor);
    lbound_c = (int) ceil ((long) lbound_c/cost_factor);

    int min_cost = INT_MAX;
    has_zero_cost = false;
    bool all_unit_cost = true;
    for (int i = 0; i < problem.actions.size(); i++) 
      {
        if (problem.actions[i].cost < min_cost && problem.actions[i].cost != 0)
          min_cost = problem.actions[i].cost;
        if (problem.actions[i].cost == 0)
          has_zero_cost = true;
        if (problem.actions[i].cost != 1)
          all_unit_cost = false;
      }

    if (!has_zero_cost)
      {
        h = min((int) h, (int) floor ((long) ubound_c/min_cost));
      }

    long long int c = ubound_c;
    bool plan_found = false;
    while (c >= lbound_c)
      {
        printf("Searching for horizon: %lld\n", h);
        printf("Searching for cost: %lld\n", cost_factor * c);
        if (all_unit_cost && sat_encoding == MADAGASCAR_SEQ)
          {
            int sol_return;
            switch (sol_method)
              {
                case KISSAT: sol_return = encodeProblemSAT(h, this->problem);
                case MADAGASCAR: sol_return = encodeProblemMadagscar(h, this->problem);
              }
            if (sol_return == 0)
              {
                break;
              }
          }
        else if (encodeProblemSAT(h, c) == 0)
          {
            break;
          }
        plan_found = true;
        printf("Current cost: %lld\n", cost_factor * c);
        fflush(stdout);
        if (c == lbound_c)
          {
            c = c - 1;
            break;
          }
        c = c - min_cost;
        if (!has_zero_cost)
          {
            h = min((int) h, (int) floor ((long) c/min_cost));
          }
      }
    if (plan_found)
      {
        return  cost_factor * (c + 1);
      }
    else
      {
        return -1;
      }
  }
