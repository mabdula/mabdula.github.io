#ifndef STRIPS_OPTIMAL
#define STRIPS_OPTIMAL

#include "../..//utils/util.h"
#include "../stripsProblem/stripsProblem.h"

#define MADAGASCAR_SEQ 0
#define MADAGASCAR_ALL 1
#define MADAGASCAR_EX 2

#define KISSAT_SAT 0
#define KISSAT_UNSAT 1
#define KISSAT_NA 2

#define KISSAT 0
#define MADAGASCAR 1
#define SMT 2


class StripsOptimal{
 public:
  StripsProblem problem;
  int sat_encoding;
  bool sym_break;
  int kissat_mode;
  int sol_method;
  //A mapping from a given cost to its cost actions
  std::map<int, std::vector<GroundActionType>> cost_actions_map;
  bool has_zero_cost;
  bool encodeProblemSMT(long long int h, long long int c);
  void transition_smt_constraints(int act_id, unsigned int t, FILE* file);
  void explicit_transition_smt_constraints(int i, unsigned int t, FILE* file);
  void factored_transition_smt_constraints(int i, FILE* file);
  long long int computeOptimalPlanCostSMT(long long int h, long long int ubound_c, long long int lbound_c);
  StripsProblem compileProblemCosts(long long int ubound_c);
  int encodeProblemSAT(long long int h, long long int c);
  int encodeProblemSAT(long long int h, StripsProblem & prob);
  int encodeProblemMadagscar(long long int h, StripsProblem & prob);
  std::vector<GroundActionType> compileActionCosts(GroundActionType act, long long int ubound_c);
  long long int computeOptimalPlanCostSAT(long long int h, long long int ubound_c, long long int lbound_c);
  void writePorblemPDDLwithCosts(long long int ubound_c);
  bool encodeProblemSAT2(long long int h, long long int c);

};

#endif
