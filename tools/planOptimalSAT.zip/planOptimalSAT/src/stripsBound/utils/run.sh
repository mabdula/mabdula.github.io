#!/bin/bash
./bound 1000 -SASSCCs -Balgo -RD.TDgt2.SSle50bound < $1
