To build:

  sudo apt-get install libboost-all-dev
  make all

To run:

  ./run.sh domain.pddl problem.pddl