#!/bin/bash
rm -rf /tmp/quotientPlan
mkdir /tmp/quotientPlan
mkdir /tmp/quotientPlan/src
mkdir /tmp/quotientPlan/bin
cd ../../
make clean
cd -
cp -rf ../../FD /tmp/quotientPlan/src/
rm -rf /tmp/quotientPlan/src/FD/src/build_all
rm -rf /tmp/quotientPlan/src/FD/src/output*
rm -rf /tmp/quotientPlan/src/FD/src/sas_plan
rm -rf /tmp/quotientPlan/src/FD/src/*tar.gz
rm -rf /tmp/quotientPlan/src/FD/src/translate/
rm -rf /tmp/quotientPlan/src/FD/src/fast-downward.py
rm -rf /tmp/quotientPlan/src/FD/src/driver/
rm -rf /tmp/quotientPlan/src/FD/src/cleanup
rm -rf /tmp/quotientPlan/src/FD/src/search/
rm -rf /tmp/quotientPlan/src/FD/src/preprocess/*
rm -rf /tmp/quotientPlan/src/FD/misc
cp -rf ../../FD/src/preprocess/helper_functions.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/variable.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/mutex_group.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/operator.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/axiom.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/state.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/domain_transition_graph.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/successor_generator.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/causal_graph.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/scc.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/max_dag.cc /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/helper_functions.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/variable.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/mutex_group.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/operator.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/axiom.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/state.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/domain_transition_graph.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/successor_generator.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/causal_graph.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/scc.h /tmp/quotientPlan/src/FD/src/preprocess/
cp -rf ../../FD/src/preprocess/max_dag.h /tmp/quotientPlan/src/FD/src/preprocess/

cp -rf ../../stripsProblem /tmp/quotientPlan/src/
rm /tmp/quotientPlan/src/stripsProblem/output*

cp -rf ../../digraphs /tmp/quotientPlan/src/
rm /tmp/quotientPlan/src/digraphs/output*

cp -rf ../../stripsSymmetry /tmp/quotientPlan/src/
rm -rf /tmp/quotientPlan/src/stripsSymmetry/utils
rm /tmp/quotientPlan/src/stripsSymmetry/*pddl
rm /tmp/quotientPlan/src/stripsSymmetry/ActionIDToName
rm /tmp/quotientPlan/src/stripsSymmetry/inst_out
rm /tmp/quotientPlan/src/stripsSymmetry/plan
rm /tmp/quotientPlan/src/stripsSymmetry/stats
rm /tmp/quotientPlan/src/stripsSymmetry/planWithQuotient
cd /tmp/quotientPlan/src/stripsSymmetry/
make clean
cd -

mkdir /tmp/quotientPlan/src/FF/
cp ../../FF/ff /tmp/quotientPlan/src/FF/ff

cp -rf ../../nauty25r9 /tmp/quotientPlan/src/
cd /tmp/quotientPlan/src/nauty25r9/
make clean
ls | grep -v '\.' | grep -v makefile | xargs rm
cd -

cp -rf ../../z3 /tmp/quotientPlan/src/
rm -rf /tmp/quotientPlan/src/z3/include
cd /tmp/quotientPlan/src/z3/bin/ && ls | grep '\.' | xargs rm && cd -

cp -rf ../../../utils/ /tmp/quotientPlan/utils


cp -rf makefile /tmp/quotientPlan/src/
cp -rf README /tmp/quotientPlan/
cp -rf run.sh /tmp/quotientPlan/bin/
cp -rf ../extract_plan.sh /tmp/quotientPlan/bin/
cd /tmp/quotientPlan/
find ./ | grep '\.gch' | xargs rm
find ./ | grep 'a.out' | xargs rm
cd -
# src/*/*.gch
# rm -rf /tmp/quotientPlan/src/*/a.out


cd /tmp
rm quotientPlan.zip
zip -r quotientPlan.zip quotientPlan/
